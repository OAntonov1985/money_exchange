import './footer.css'


export default function Footer() {
    return (
        <>
            <div className='fooret'>Створено із натхненням від дій ЗСУ  і особливо 3 штурмової Бригади АЗОВ за їх же підтримки</div>
        </>
    );
}